<div class="footer text-muted">
<a href="http://adctechno.com/" target="_blank">&nbsp;Design & Develop By Ad Concept Technologies.</a>
</div>
<!-- /footer -->
		
<script>
	initSample();
	initSample1();
</script>